[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /opt/lampp/htdocs/bulk-email/resources/views/vendor/mail/text/header.blade.php ENDPATH**/ ?>
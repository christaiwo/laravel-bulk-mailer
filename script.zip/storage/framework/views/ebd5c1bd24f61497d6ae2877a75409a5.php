<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/bulk-email/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>
<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /opt/lampp/htdocs/bulk-email/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>